<?php
/**
 * Plugin Name: CAPTCHAS.co Drop-in Widget
 * Plugin URI:  https://github.com/CAPTCHASCO/Wordpress-Plugin
 * Description: Drop-in widget embed for CAPTCHAS.co (shortcode, block, and widget) with a simple settings page.
 * Version:     1.0.1
 * Author:      CAPTCHAS.co
 * Author URI:  https://captchas.co
 * License:     GPL-2.0-or-later
 * Text Domain: captchas-co-drop-in-widget
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) exit;

final class CAPTCHASCO_Dropin_Widget_Plugin {
	const OPTION_KEY = 'captchasco_dropin_settings';

	public function __construct() {
		add_action('init', [$this, 'init']);
		add_action('admin_menu', [$this, 'admin_menu']);
		add_action('admin_init', [$this, 'admin_init']);
		add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
		add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);

		add_shortcode('captchas_widget', [$this, 'shortcode']);

		add_action('widgets_init', function () {
			register_widget('CAPTCHASCO_Dropin_WP_Widget');
		});
	}

	public function init() {
		// NOTE: When hosted on WordPress.org, translations are loaded automatically.
		// No need to call load_plugin_textdomain().

		wp_register_script(
			'captchasco-dropin-block',
			plugins_url('assets/block.js', __FILE__),
			['wp-blocks', 'wp-element', 'wp-components', 'wp-editor', 'wp-i18n'],
			'1.0.1',
			true
		);

		register_block_type('captchasco/dropin-widget', [
			'editor_script'   => 'captchasco-dropin-block',
			'render_callback' => [$this, 'render_embed'],
			'attributes'      => [
				'title' => ['type' => 'string', 'default' => ''],
			],
		]);
	}

	public function admin_menu() {
		add_options_page(
			__('CAPTCHAS.co Drop-in Widget', 'captchas-co-drop-in-widget'),
			__('CAPTCHAS.co Widget', 'captchas-co-drop-in-widget'),
			'manage_options',
			'captchasco-dropin',
			[$this, 'settings_page']
		);
	}

	public function admin_init() {
		register_setting('captchasco_dropin_group', self::OPTION_KEY, [
			'type'              => 'array',
			'sanitize_callback' => [$this, 'sanitize_settings'],
			'default'           => [
				'embed_type'   => 'iframe',
				'embed_url'    => '',
				'script_url'   => '',
				'container_id' => 'captchasco-widget',
				'height'       => '600',
				'width'        => '100',
				'width_unit'   => '%',
				'title'        => 'CAPTCHAS.co Widget',
				'allow'        => 'clipboard-write; fullscreen',
			],
		]);
	}

	public function admin_assets($hook) {
		if ($hook !== 'settings_page_captchasco-dropin') return;

		wp_enqueue_style(
			'captchasco-dropin-admin',
			plugins_url('assets/admin.css', __FILE__),
			[],
			'1.0.1'
		);

		wp_enqueue_script(
			'captchasco-dropin-admin',
			plugins_url('assets/admin.js', __FILE__),
			[],
			'1.0.1',
			true
		);
	}

	public function frontend_assets() {
		$opts = $this->get_settings();
		if (($opts['embed_type'] ?? 'iframe') === 'script' && !empty($opts['script_url'])) {
			wp_register_script(
				'captchasco-dropin-remote',
				esc_url_raw($opts['script_url']),
				[],
				null,
				true
			);
		}
	}

	private function get_settings() {
		$opts = get_option(self::OPTION_KEY);
		if (!is_array($opts)) $opts = [];
		$defaults = [
			'embed_type'   => 'iframe',
			'embed_url'    => '',
			'script_url'   => '',
			'container_id' => 'captchasco-widget',
			'height'       => '600',
			'width'        => '100',
			'width_unit'   => '%',
			'title'        => 'CAPTCHAS.co Widget',
			'allow'        => 'clipboard-write; fullscreen',
		];
		return array_merge($defaults, $opts);
	}

	public function sanitize_settings($input) {
		$in = is_array($input) ? $input : [];

		$embed_type = (isset($in['embed_type']) && $in['embed_type'] === 'script') ? 'script' : 'iframe';

		$embed_url  = isset($in['embed_url']) ? trim((string)$in['embed_url']) : '';
		$script_url = isset($in['script_url']) ? trim((string)$in['script_url']) : '';

		$embed_url  = $embed_url ? esc_url_raw($embed_url, ['http', 'https']) : '';
		$script_url = $script_url ? esc_url_raw($script_url, ['http', 'https']) : '';

		$container_id = isset($in['container_id']) ? sanitize_html_class((string)$in['container_id']) : 'captchasco-widget';

		$height = isset($in['height']) ? preg_replace('/[^0-9]/', '', (string)$in['height']) : '600';
		if ($height === '') $height = '600';

		$width = isset($in['width']) ? preg_replace('/[^0-9]/', '', (string)$in['width']) : '100';
		if ($width === '') $width = '100';

		$width_unit = (isset($in['width_unit']) && $in['width_unit'] === 'px') ? 'px' : '%';

		$title = isset($in['title']) ? sanitize_text_field((string)$in['title']) : 'CAPTCHAS.co Widget';

		$allow = isset($in['allow']) ? preg_replace('/[^a-zA-Z0-9\-; :]/', '', (string)$in['allow']) : 'clipboard-write; fullscreen';

		return [
			'embed_type'   => $embed_type,
			'embed_url'    => $embed_url,
			'script_url'   => $script_url,
			'container_id' => $container_id,
			'height'       => $height,
			'width'        => $width,
			'width_unit'   => $width_unit,
			'title'        => $title,
			'allow'        => $allow,
		];
	}

	public function settings_page() {
		if (!current_user_can('manage_options')) return;

		$opts = $this->get_settings();
		?>
		<div class="wrap captchasco-admin">
			<h1><?php echo esc_html__('CAPTCHAS.co Drop-in Widget', 'captchas-co-drop-in-widget'); ?></h1>

			<p class="description">
				<?php echo esc_html__('Configure how the widget is embedded. Then use the shortcode, block, or widget to display it.', 'captchas-co-drop-in-widget'); ?>
			</p>

			<form method="post" action="options.php">
				<?php settings_fields('captchasco_dropin_group'); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php echo esc_html__('Embed method', 'captchas-co-drop-in-widget'); ?></th>
						<td>
							<label>
								<input type="radio" name="<?php echo esc_attr(self::OPTION_KEY); ?>[embed_type]" value="iframe" <?php checked($opts['embed_type'], 'iframe'); ?> />
								<?php echo esc_html__('IFrame (embed URL)', 'captchas-co-drop-in-widget'); ?>
							</label>
							<br/>
							<label>
								<input type="radio" name="<?php echo esc_attr(self::OPTION_KEY); ?>[embed_type]" value="script" <?php checked($opts['embed_type'], 'script'); ?> />
								<?php echo esc_html__('Script (script URL + container)', 'captchas-co-drop-in-widget'); ?>
							</label>
						</td>
					</tr>

					<tr class="captchasco-row captchasco-row-iframe">
						<th scope="row"><?php echo esc_html__('Widget embed URL', 'captchas-co-drop-in-widget'); ?></th>
						<td>
							<input type="url" class="regular-text code" name="<?php echo esc_attr(self::OPTION_KEY); ?>[embed_url]" value="<?php echo esc_attr($opts['embed_url']); ?>" placeholder="https://…" />
							<p class="description"><?php echo esc_html__('Paste the full URL you were given for embedding (recommended).', 'captchas-co-drop-in-widget'); ?></p>
						</td>
					</tr>

					<tr class="captchasco-row captchasco-row-script">
						<th scope="row"><?php echo esc_html__('Script URL', 'captchas-co-drop-in-widget'); ?></th>
						<td>
							<input type="url" class="regular-text code" name="<?php echo esc_attr(self::OPTION_KEY); ?>[script_url]" value="<?php echo esc_attr($opts['script_url']); ?>" placeholder="https://…" />
							<p class="description"><?php echo esc_html__('Paste the remote script URL used to load the widget.', 'captchas-co-drop-in-widget'); ?></p>
						</td>
					</tr>

					<tr class="captchasco-row captchasco-row-script">
						<th scope="row"><?php echo esc_html__('Container ID', 'captchas-co-drop-in-widget'); ?></th>
						<td>
							<input type="text" class="regular-text code" name="<?php echo esc_attr(self::OPTION_KEY); ?>[container_id]" value="<?php echo esc_attr($opts['container_id']); ?>" />
							<p class="description"><?php echo esc_html__('The widget will render inside this element id.', 'captchas-co-drop-in-widget'); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php echo esc_html__('Size', 'captchas-co-drop-in-widget'); ?></th>
						<td>
							<label>
								<?php echo esc_html__('Width', 'captchas-co-drop-in-widget'); ?>
								<input type="text" class="small-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[width]" value="<?php echo esc_attr($opts['width']); ?>" />
							</label>
							<select name="<?php echo esc_attr(self::OPTION_KEY); ?>[width_unit]">
								<option value="%" <?php selected($opts['width_unit'], '%'); ?>>%</option>
								<option value="px" <?php selected($opts['width_unit'], 'px'); ?>>px</option>
							</select>

							&nbsp;&nbsp;

							<label>
								<?php echo esc_html__('Height (px)', 'captchas-co-drop-in-widget'); ?>
								<input type="text" class="small-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[height]" value="<?php echo esc_attr($opts['height']); ?>" />
							</label>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php echo esc_html__('Title / Accessibility', 'captchas-co-drop-in-widget'); ?></th>
						<td>
							<input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[title]" value="<?php echo esc_attr($opts['title']); ?>" />
							<p class="description"><?php echo esc_html__('Used as iframe title and fallbacks for accessibility.', 'captchas-co-drop-in-widget'); ?></p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php echo esc_html__('IFrame allow attribute', 'captchas-co-drop-in-widget'); ?></th>
						<td>
							<input type="text" class="regular-text code" name="<?php echo esc_attr(self::OPTION_KEY); ?>[allow]" value="<?php echo esc_attr($opts['allow']); ?>" />
							<p class="description"><?php echo esc_html__('Optional. Controls permissions for embedded content.', 'captchas-co-drop-in-widget'); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button(__('Save changes', 'captchas-co-drop-in-widget')); ?>
			</form>

			<hr/>

			<h2><?php echo esc_html__('How to use', 'captchas-co-drop-in-widget'); ?></h2>
			<ul>
				<li><code>[captchas_widget]</code></li>
				<li><code>[captchas_widget title="Optional title override"]</code></li>
				<li><?php echo esc_html__('Gutenberg: add the “CAPTCHAS.co Drop-in Widget” block.', 'captchas-co-drop-in-widget'); ?></li>
				<li><?php echo esc_html__('Appearance → Widgets: add “CAPTCHAS.co Drop-in Widget”.', 'captchas-co-drop-in-widget'); ?></li>
			</ul>
		</div>
		<?php
	}

	public function shortcode($atts = []) {
		$atts = shortcode_atts([
			'title' => '',
		], $atts, 'captchas_widget');

		return $this->render_embed([
			'title' => (string)$atts['title'],
		]);
	}

	public function render_embed($attrs = []) {
		$opts = $this->get_settings();
		$title_override = '';
		if (is_array($attrs) && isset($attrs['title'])) {
			$title_override = sanitize_text_field((string)$attrs['title']);
		}
		$title = ($title_override !== '') ? $title_override : $opts['title'];

		$embed_type = $opts['embed_type'];
		$width_css = $opts['width'] . $opts['width_unit'];
		$height_css = $opts['height'] . 'px';

		if ($embed_type === 'script') {
			$container_id = $opts['container_id'] ?: 'captchasco-widget';

			if (!empty($opts['script_url'])) {
				wp_enqueue_script('captchasco-dropin-remote');
			}

			ob_start(); ?>
			<div class="captchasco-dropin" style="width: <?php echo esc_attr($width_css); ?>;">
				<div id="<?php echo esc_attr($container_id); ?>" data-title="<?php echo esc_attr($title); ?>"></div>
			</div>
			<?php
			return ob_get_clean();
		}

		if (empty($opts['embed_url'])) {
			if (current_user_can('manage_options')) {
				return '<div class="captchasco-dropin notice notice-warning"><p>' .
					esc_html__('CAPTCHAS.co widget is not configured. Please set an embed URL in Settings → CAPTCHAS.co Widget.', 'captchas-co-drop-in-widget') .
					'</p></div>';
			}
			return '';
		}

		$src = esc_url($opts['embed_url']);
		$allow = trim($opts['allow']);

		ob_start(); ?>
		<div class="captchasco-dropin" style="width: <?php echo esc_attr($width_css); ?>;">
			<iframe
				title="<?php echo esc_attr($title); ?>"
				src="<?php echo $src; ?>"
				style="width: 100%; height: <?php echo esc_attr($height_css); ?>; border: 0;"
				loading="lazy"
				referrerpolicy="no-referrer-when-downgrade"
				<?php if ($allow !== ''): ?>
					allow="<?php echo esc_attr($allow); ?>"
				<?php endif; ?>
			></iframe>
		</div>
		<?php
		return ob_get_clean();
	}
}

class CAPTCHASCO_Dropin_WP_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'captchasco_dropin_widget',
			__('CAPTCHAS.co Drop-in Widget', 'captchas-co-drop-in-widget'),
			['description' => __('Embeds the CAPTCHAS.co widget.', 'captchas-co-drop-in-widget')]
		);
	}

	public function widget($args, $instance) {
		$title = isset($instance['title']) ? sanitize_text_field($instance['title']) : '';
		echo $args['before_widget'];

		if (!empty($title)) {
			echo $args['before_title'] . esc_html($title) . $args['after_title'];
		}

		$plugin = new CAPTCHASCO_Dropin_Widget_Plugin();
		echo $plugin->render_embed(['title' => $title]);

		echo $args['after_widget'];
	}

	public function form($instance) {
		$title = isset($instance['title']) ? esc_attr($instance['title']) : '';
		?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'captchas-co-drop-in-widget'); ?></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
				   name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
				   value="<?php echo $title; ?>" />
		</p>
		<p class="description">
			<?php esc_html_e('Configure the embed in Settings → CAPTCHAS.co Widget.', 'captchas-co-drop-in-widget'); ?>
		</p>
		<?php
	}

	public function update($new_instance, $old_instance) {
		$instance = [];
		$instance['title'] = isset($new_instance['title']) ? sanitize_text_field($new_instance['title']) : '';
		return $instance;
	}
}

$GLOBALS['captchasco_dropin_widget_plugin'] = new CAPTCHASCO_Dropin_Widget_Plugin();
