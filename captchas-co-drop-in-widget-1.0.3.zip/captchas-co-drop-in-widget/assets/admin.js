(function () {
  function toggleRows() {
    var iframeRows = document.querySelectorAll('.captchasco-row-iframe');
    var scriptRows = document.querySelectorAll('.captchasco-row-script');
    var script = document.querySelector('input[value="script"][name*="[embed_type]"]');

    var mode = (script && script.checked) ? 'script' : 'iframe';

    iframeRows.forEach(function (el) { el.style.display = (mode === 'iframe') ? '' : 'none'; });
    scriptRows.forEach(function (el) { el.style.display = (mode === 'script') ? '' : 'none'; });
  }

  document.addEventListener('change', function (e) {
    if (e.target && e.target.name && e.target.name.indexOf('[embed_type]') !== -1) {
      toggleRows();
    }
  });

  document.addEventListener('DOMContentLoaded', toggleRows);
})();
