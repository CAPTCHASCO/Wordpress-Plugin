(function (blocks, element, components, editor, i18n) {
  var el = element.createElement;
  var __ = i18n.__;

  blocks.registerBlockType('captchasco/dropin-widget', {
    title: __('CAPTCHAS.co Drop-in Widget', 'captchas-co-drop-in-widget'),
    icon: 'shield',
    category: 'widgets',
    attributes: {
      title: { type: 'string', default: '' }
    },
    edit: function (props) {
      var title = props.attributes.title;

      return el('div', { className: props.className },
        el('p', {}, __('This block renders the widget on the front end using your plugin settings.', 'captchas-co-drop-in-widget')),
        el(components.TextControl, {
          label: __('Optional title override', 'captchas-co-drop-in-widget'),
          value: title,
          onChange: function (val) { props.setAttributes({ title: val }); }
        }),
        el('p', { style: { opacity: 0.7 } },
          __('Preview is rendered on the front end (server-side).', 'captchas-co-drop-in-widget')
        )
      );
    },
    save: function () { return null; }
  });
})(window.wp.blocks, window.wp.element, window.wp.components, window.wp.editor, window.wp.i18n);
