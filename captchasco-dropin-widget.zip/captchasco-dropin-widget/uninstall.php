<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
delete_option('captchasco_dropin_settings');
