=== CAPTCHAS.co Drop-in Widget ===
Contributors: yourname
Tags: widget, embed, shortcode, block
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Drop-in widget embed for CAPTCHAS.co (shortcode, block, and widget) with a simple settings page.

== Description ==
Configure an embed URL (iframe) or a script URL + container ID, then place the widget using:
- Shortcode: [captchas_widget]
- Block: CAPTCHAS.co Drop-in Widget
- Widget: CAPTCHAS.co Drop-in Widget

== Installation ==
1. Upload the plugin folder to /wp-content/plugins/
2. Activate in Plugins
3. Go to Settings → CAPTCHAS.co Widget
4. Paste your embed URL (recommended) or script URL

== Frequently Asked Questions ==
= How do I embed it? =
Use [captchas_widget] or the block/widget.

== Changelog ==
= 1.0.0 =
Initial release.
